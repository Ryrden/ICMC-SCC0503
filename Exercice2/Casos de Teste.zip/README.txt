Arquivo zip gerado em: 06/05/2022 14:05:38 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Exercício 2 - Registros de Alunos com Busca por Índices Primários