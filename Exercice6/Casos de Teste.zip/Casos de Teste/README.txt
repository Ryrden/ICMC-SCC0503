Arquivo zip gerado em: 24/07/2022 12:06:03 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Exercício Bônus B - Credo dos Frita Sinos: Infinidade - O Processo Seletivo